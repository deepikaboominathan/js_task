var showMessage;

showMessage = function (message) {
    console.log("The message is: " + message + " Have a nice day!");
};


showMessage("Hello, world!");

showMessage("JavaScript is awesome!");
showMessage("Keep coding!");

