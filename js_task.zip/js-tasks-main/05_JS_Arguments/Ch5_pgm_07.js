var showPlayerName;

showPlayerName = function (playerName) {
    console.log("The player's name is " + playerName);
    console.log("The player's name has " + playerName.length + " letters.");
};

showPlayerName("Hari");
showPlayerName("Kumaran");
