var message;
var showMessage;


message = "Hello, world!";

showMessage = function () {
    console.log(message);
};


showMessage();
