var showMessage;

showMessage = function (message) {
    console.log("The message is:");
    console.log(message);
};

showMessage("It's full of stars!");
showMessage("Hello to Jason Isaacs");
showMessage("Hello to Jason Isaacs and Stephen Fry");


var myMessage = "This is a custom message.";

showMessage(myMessage);
