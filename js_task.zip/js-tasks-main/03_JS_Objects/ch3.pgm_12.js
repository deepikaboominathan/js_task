var post = {
    id: 1,
    title: "My Crazy Space Adventure",
    author: "Philae",
    created: "2015-06-21",
    body: "You will not believe where I just woke up!! Only on a comet..."
};

console.log("Post Title:", post.title);
console.log("Author:", post.author);
console.log("Created Date:", post.created);

var post2 = {
    id: 2,
    title: "Exploring the Red Planet",
    author: "Curiosity Rover",
    created: "2012-08-06",
    body: "Driving around Mars, discovering new landscapes and sending back stunning photos."
};

console.log("\nSecond Post Title:", post2.title);
console.log("Author:", post2.author);
console.log("Created Date:", post2.created);
