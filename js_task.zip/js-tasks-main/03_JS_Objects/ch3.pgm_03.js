var book;

book = {
    title : "The Hobbit",
    author : "J. R. R. Tolkien",
    published : 1937
};

console.log(book);

var book2;

book2 = {
    title: "Northern Lights",
    author: "Philip Pullman",
    published: 1995
};

console.log(book2);