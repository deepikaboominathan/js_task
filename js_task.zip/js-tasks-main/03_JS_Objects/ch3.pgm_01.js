// Using variables to represent a book

var bookTitle;
var bookAuthor;

// Assign values for the first book
bookTitle = "The Hobbit";
bookAuthor = "J. R. R. Tolkien";

// Log details of the first book to the console
console.log(bookTitle + " by " + bookAuthor);

// Further Adventures

// 1) Declare variables for a second book and assign them values.
var secondBookTitle = "Harry Potter and the Philosopher's Stone";
var secondBookAuthor = "J.K. Rowling";

// 2) Add code to log its details to the console.
console.log(secondBookTitle + " by " + secondBookAuthor);

// 3) Declare variables for a third book and assign them values.
var thirdBookTitle = "1984";
var thirdBookAuthor = "George Orwell";

// 4) Add code to log its details to the console.
console.log(thirdBookTitle + " by " + thirdBookAuthor);

// Example for 10 books:
// var book1Title = "...";
// var book1Author = "...";
// var book2Title = "...";
// var book2Author = "...";
// ...
// var book10Title = "...";
// var book10Author = "...";
