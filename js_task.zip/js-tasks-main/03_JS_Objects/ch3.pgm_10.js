var player1;

player1 = {
    name: "Max",
    attempted: 0,
    correct: 0
};

player1.attempted = 2;
player1.correct = 2;
player1.score = 100;

console.log(player1);
