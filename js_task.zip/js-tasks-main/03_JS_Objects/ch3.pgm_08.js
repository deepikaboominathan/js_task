var book;

book = {
    title     : "The Hobbit",
	author    : "J. R. R. Tolkien",
	published : 1937
};

console.log(book.title);
console.log(book.author);
console.log(book.published);

book2 = {
    title     : "Ghost Rider",
    author    : "Devil",
    published : 1995
};

console.log(book2.title);
console.log(book2.author);
console.log(book2.published);

