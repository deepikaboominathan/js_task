var book1;
var book2;

book1 = {
    title     : "The Hobbit",
    author    : "J. R. R. Tolkien",
    published : 1939
};

book2 = {
    title     : "Northern Lights",
    author    : "Philip Pullman",
    published : 1997
};

console.log(book1);
console.log(book2);
