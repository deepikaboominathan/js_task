var book;
var bookName;

bookName = "The Adventures of Tom Sawyer";

book = {
    title : bookName
};
 console.log(book);


var book;
var bookName;

bookName = "1984";

book = {
    title: bookName
};

console.log(book);

