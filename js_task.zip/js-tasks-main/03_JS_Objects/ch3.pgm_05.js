var book;

book = {
    title: "Jilla"
};

console.log(book);

var book2;

book2 = {
    title: "Mersal"
};

console.log(book2);