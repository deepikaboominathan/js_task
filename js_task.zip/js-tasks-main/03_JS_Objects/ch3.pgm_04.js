var book;

book = {

};

console.log(book);
