var book1Title = "The Hobbit";
var book1Author = "J.R.R.Tolkien";

var book2Title = "Northern Lights";
var book2Author = "Philip Pullman";

var book3Title = "The Adventures of Tom Sawyer";
var book3Author = "Mark Twain";

var book4Title = "Avengers endgame";
var book4Author = "Joss Whedon";


console.log("There are four books so far...");
console.log(book1Title + " by " + book1Author);
console.log(book2Title + " by " + book2Author);
console.log(book3Title + " by " + book3Author);
console.log(book4Title + " by " + book4Author);