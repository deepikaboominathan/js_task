var displayMenu;

displayMenu = function () {
	console.log("Please choose an option:");
	console.log("(1) Print log");
	console.log("(2) Upload file");
	console.log("(3) Download");
	console.log("(4) Contacts");
	console.log("(9) Quit");
};

displayMenu();
var displayMenu = function() {
    console.log("Welcome to My custom menu:");
    console.log("(1) View profile");
    console.log("(2) Edit models");
    console.log("(3) Quit");

}

displayMenu();