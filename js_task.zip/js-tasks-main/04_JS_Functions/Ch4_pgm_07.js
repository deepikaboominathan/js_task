var number1 = 1500;
var number2 = 1166;
var number3 = 1236;
var result;
var findTotal;

findTotal = function () {
	result = number1 + number2 + number3;
};

findTotal();

console.log(number1 + " + " + number2 + " + " + number3 + " = " + result);
