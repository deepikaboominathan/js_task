var sayHello;

sayHello = function () {
    console.log("Hello World!");
};

sayHello(); // Calling the function to run it
