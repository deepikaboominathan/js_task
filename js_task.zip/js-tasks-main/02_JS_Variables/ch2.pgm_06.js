var playerName;
var locationName;

playerName = "Spiderman"
locationName = "Paris"

console.log(playerName + " is in " + locationName);

var score;
score = 1000;

console.log(playerName + " has a score of " + score);