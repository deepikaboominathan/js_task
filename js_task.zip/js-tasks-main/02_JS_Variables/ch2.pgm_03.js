var score;
score = 100;
score2 = 200;
console.log(score);
console.log(score2)
