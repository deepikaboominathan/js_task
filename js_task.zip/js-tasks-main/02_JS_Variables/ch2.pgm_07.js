var playerName = "vijay";
var locationName = "The Greatest of all time";

console.log(playerName + " is in " + locationName)

var health = "80"

var message;
message = playerName + " has health " + health + " and is in " + locationName;
console.log(message)