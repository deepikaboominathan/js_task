var thisIsFine;
console.log(thisIsFine);
 var $noProblemHere;
 console.log($noProblemHere);
var _underscore56;
console.log(_underscore56);
var StartWithCapital;
console.log(StartWithCapital);
var z5;
console.log(z5);

var message = (999);
console.log(message);

var foot= "39Steps";
console.log(foot);

var box = "&nope";
console.log(box);
var string = "single words only";
console.log(string);
var check = "yield";
console.log(check);