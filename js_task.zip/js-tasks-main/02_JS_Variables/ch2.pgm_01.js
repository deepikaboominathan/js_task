var score = 300;
console.log(score)