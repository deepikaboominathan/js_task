var score;
score= 100;
console.log("Your score was" + score)

console.log("Great splat!!!");
score = score + 100;
console.log("New score: " + score);

console.log("Way to go!");
console.log("You splatted a kumquat!");

score = score + 100;
console.log("New score: " + score);

console.log("Congratulations! You're on fire!");