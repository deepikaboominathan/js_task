var message
message = "Hello World!";
console.log(message)

message = "'Congratulations! Your tweet has won a prize...';";
console.log(message)

message = "Welcome to world of javascript"
console.log(message)

message = "Hello " + "World!";
console.log(message)

message = 'Congratulations' + '! ' + 'Your tweet' + ' has won a prize...';
console.log(message); 