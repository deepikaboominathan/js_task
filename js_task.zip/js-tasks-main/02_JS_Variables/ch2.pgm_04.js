var score;


score = 100;
console.log(score);

score = 150;
console.log(score);


score = 200;
console.log(score); 


var score2;

score2 = 50;
console.log(score2); 

score2 = 75;


console.log(score2); 
