var score = 500;
console.log(score)